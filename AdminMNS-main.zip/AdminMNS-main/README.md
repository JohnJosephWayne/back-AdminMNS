# AdminMNS
registration, absence an lateness management
