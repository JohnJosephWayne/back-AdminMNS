package com.project.adminmns.view;

public class ModelUserView {
}
